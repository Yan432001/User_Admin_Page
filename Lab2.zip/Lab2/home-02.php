


	<!-- Header -->

	<!-- Sidebar -->
<?php include "include/slidebar.php"; ?>

	<!-- Cart -->
<?php include "include/cart.php"; ?>



	<!-- Slider -->
<?php include "include/slider.php"; ?>

	<!-- Banner -->
<?php include "include/banner.php"; ?>

	<!-- Product -->
<?php include "include/product.php"; ?>


	<!-- Blog -->
<?php include "include/blog.php"; ?>




	<!-- Modal1 -->
<?php include "include/modal1.php"; ?>
  <!-- script  -->
  <?php include "include/scriptHome.php"; ?>

