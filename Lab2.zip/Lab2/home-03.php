


	<!-- Sidebar -->
<?php include "include/slidebar.php"; ?>

	<!-- Cart -->
<?php include "include/cart.php"; ?>



	<!-- Slider -->
<?php include "include/sliderFF.php"; ?>

	<!-- Banner -->
<?php include "include/bannerFF.php"; ?>

	<!-- Product -->
	<section class="bg0 p-t-23 p-b-130">
		<div class="container">
			<div class="p-b-10">
				<h3 class="ltext-103 cl5">
					Product Overview
				</h3>
			</div>

<?php include "include/containerProduct.php"; ?>

<?php include "include/containerProduct1.php"; ?>

			<!-- Pagination -->
			<div class="flex-c-m flex-w w-full p-t-38">
				<a href="#" class="flex-c-m how-pagination1 trans-04 m-all-7 active-pagination1">
					1
				</a>

				<a href="#" class="flex-c-m how-pagination1 trans-04 m-all-7">
					2
				</a>
			</div>
		</div>
	</section>





	<!-- Modal1 -->
<?php include "include/modal1.php"; ?>

<?php include "include/scriptHome.php"; ?>
