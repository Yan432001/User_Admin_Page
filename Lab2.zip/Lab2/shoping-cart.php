
	<!-- Cart -->
<?php include "include/cart.php"; ?>

	<!-- breadcrumb -->
	<div class="container">
		<div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
			<a href="index.php" class="stext-109 cl8 hov-cl1 trans-04">
				Home
				<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
			</a>

			<span class="stext-109 cl4">
				Shoping Cart
			</span>
		</div>
	</div>
		

	<!-- Shoping Cart -->
	<form class="bg0 p-t-75 p-b-85">
		<div class="container">
			<div class="row">
<?php include "include/cartLeft.php"; ?>
<?php include "include/cartRight.php"; ?>
			</div>
		</div>
	</form>
		
	
		



<!-- Modal1 -->
<?php include "include/modal1.php"; ?>

<?php include "include/scriptHome.php"; ?>

</body>
</html>