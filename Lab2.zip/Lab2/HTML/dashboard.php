<!-- Sale & Revenue Start -->
<?php include "includes/saleRevenue.php"; ?>
<!-- Sale & Revenue End -->


<!-- Sales Chart Start -->
<?php include "includes/saleChart.php"; ?>
<!-- Sales Chart End -->


<!-- Recent Sales Start -->
<?php include "includes/saleStart.php"; ?>
<!-- Recent Sales End -->


<!-- Widgets Start -->
<?php include "includes/widgets.php"; ?>
<!-- Widgets End -->

<!-- Content Start -->