<?php
$page = "dashboard.php";

if (isset($_GET['a'])) {
    $a = $_GET['a'];
    switch ($a) {
        case "category":
            $page = "category.php";
            break;
        case "slideshow":
            $page = "slideshow.php";
            break;
        case "pro":
            $page = "pro.php";
            break;
        case "user":
            $page = "User.php";
            break;
        case "signin":
            $page = "signin.php";
            break;
        case "signup":
            $page = "signup.php";
            break;
        case "404":
            $page = "404.php";
            break;
        case "configuration":
            $page = "configuration.php";
            break;

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include "includes/head.php"; ?>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php include "includes/slider.php"; ?>
        <!-- Sidebar End -->

        <div class="content">
            <!-- Navbar Start -->
            <?php include "includes/nav.php"; ?>

            <?php include $page ?>
            <!-- Content End -->
            <!-- Footer Start -->
            <?php include "includes/footer.php"; ?>
<!-- Footer End -->
        </div>

            <!-- Back to Top -->
            <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <?php include "includes/script.php"; ?>
</body>

</html>