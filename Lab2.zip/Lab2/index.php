<?php
$page = "home-02.php";
$footer = true;

if(isset($_GET['p']))
{
    $p = $_GET['p'];
    switch($p){
        case "home3":
            $page = "home-03.php";
            break;
        case "product":
            $page = "product.php";
            break;
        case "features":
            $page = "shoping-cart.php";
            break;
        case "blog":
            $page = "blog.php";
            break;
        case "about":
            $page = "about.php";
            break;
        case "contact":
            $page = "contact.php";
            break;
        case "de":
            $page = "de.php";
            $footer = false;
            break;
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<?php include "include/headHome.php"; ?>

<body class="animsition">

    <!-- Header -->
    <?php include "include/header.php"; ?>
    <!-- Sidebar -->
    <?php include $page ?>


    	<!-- Footer -->
<?php if($footer) include "include/footer.php"; ?>

<!-- Back to top -->
<?php include "include/back.php"; ?>

</body>

</html>