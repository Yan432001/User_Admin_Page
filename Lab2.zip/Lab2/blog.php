
	<!-- Cart -->
<?php include 'include/cart.php'; ?>

	<!-- Title page -->
	<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-image: url('images/bg-02.jpg');">
		<h2 class="ltext-105 cl0 txt-center">
			Blog
		</h2>
	</section>	


	<!-- Content page -->
	<section class="bg0 p-t-62 p-b-60">
		<div class="container">
			<div class="row">
<?php include "include/blogLeftContain.php"; ?>
<?php include "include/blogRightContant.php"; ?>
			</div>
		</div>
	</section>	
	
		


<?php include "include/script.php"; ?>
